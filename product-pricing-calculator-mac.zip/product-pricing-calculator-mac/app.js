const state = {
  exchangeRate: null,
  exchangeRateSource: "pending",
};

const STORAGE_KEY = "product-pricing-calculator-sessions";
const THEME_STORAGE_KEY = "product-pricing-calculator-theme";
let memorySessions = [];

const els = {
  addRow: document.getElementById("add-row"),
  loadSample: document.getElementById("load-sample"),
  resetForm: document.getElementById("reset-form"),
  themeToggle: document.getElementById("theme-toggle"),
  purchaseCurrency: document.getElementById("purchase-currency"),
  purchaseDate: document.getElementById("purchase-date"),
  customsTotal: document.getElementById("customs-total"),
  shippingTotal: document.getElementById("shipping-total"),
  vatPercent: document.getElementById("vat-percent"),
  manualRate: document.getElementById("manual-rate"),
  sessionName: document.getElementById("session-name"),
  savedSessions: document.getElementById("saved-sessions"),
  saveSession: document.getElementById("save-session"),
  loadSession: document.getElementById("load-session"),
  importJson: document.getElementById("import-json"),
  importJsonInput: document.getElementById("import-json-input"),
  importAllJson: document.getElementById("import-all-json"),
  deleteSession: document.getElementById("delete-session"),
  exportCsv: document.getElementById("export-csv"),
  sessionFeedback: document.getElementById("session-feedback"),
  fxRate: document.getElementById("fx-rate"),
  fxStatus: document.getElementById("fx-status"),
  rows: document.getElementById("product-rows"),
  rowTemplate: document.getElementById("row-template"),
  summaryBuySubtotal: document.getElementById("summary-buy-subtotal"),
  summaryCustoms: document.getElementById("summary-customs"),
  summaryShipping: document.getElementById("summary-shipping"),
  summaryLanded: document.getElementById("summary-landed"),
  summaryCostIncVat: document.getElementById("summary-cost-inc-vat"),
  summarySalesTotal: document.getElementById("summary-sales-total"),
  summaryOutputVat: document.getElementById("summary-output-vat"),
  summaryCompanyGain: document.getElementById("summary-company-gain"),
  summaryNetMargin: document.getElementById("summary-net-margin"),
};

const today = new Date().toISOString().slice(0, 10);

const requiredElementKeys = [
  "addRow",
  "loadSample",
  "resetForm",
  "themeToggle",
  "purchaseCurrency",
  "purchaseDate",
  "customsTotal",
  "shippingTotal",
  "vatPercent",
  "manualRate",
  "sessionName",
  "savedSessions",
  "saveSession",
  "loadSession",
  "importJson",
  "importJsonInput",
  "importAllJson",
  "deleteSession",
  "exportCsv",
  "sessionFeedback",
  "fxRate",
  "fxStatus",
  "rows",
  "rowTemplate",
  "summaryBuySubtotal",
  "summaryCustoms",
  "summaryShipping",
  "summaryLanded",
  "summaryCostIncVat",
  "summarySalesTotal",
  "summaryOutputVat",
  "summaryCompanyGain",
  "summaryNetMargin",
];

function hasRequiredElements() {
  return requiredElementKeys.every((key) => els[key]);
}

function isFileProtocol() {
  return window.location.protocol === "file:";
}

function formatMoney(value, currency) {
  return new Intl.NumberFormat("en-US", {
    style: "currency",
    currency,
    minimumFractionDigits: 2,
    maximumFractionDigits: 2,
  }).format(Number.isFinite(value) ? value : 0);
}

function formatPercent(value) {
  return `${(Number.isFinite(value) ? value : 0).toFixed(1)}%`;
}

function clamp(value, min, max) {
  return Math.min(Math.max(value, min), max);
}

function getNumericValue(input) {
  const value = Number.parseFloat(input.value);
  return Number.isFinite(value) ? value : 0;
}

function setFeedback(message) {
  els.sessionFeedback.textContent = message;
}

function applyTheme(theme) {
  const nextTheme = theme === "light" ? "light" : "dark";
  document.body.dataset.theme = nextTheme;
  els.themeToggle.textContent = nextTheme === "dark" ? "Switch to light mode" : "Switch to dark mode";
}

function loadThemePreference() {
  try {
    return window.localStorage.getItem(THEME_STORAGE_KEY) || "dark";
  } catch (error) {
    console.error(error);
    return "dark";
  }
}

function toggleTheme() {
  const nextTheme = document.body.dataset.theme === "light" ? "dark" : "light";
  applyTheme(nextTheme);
  try {
    window.localStorage.setItem(THEME_STORAGE_KEY, nextTheme);
  } catch (error) {
    console.error(error);
  }
}

function escapeCsvValue(value) {
  const stringValue = String(value ?? "");
  return `"${stringValue.replaceAll('"', '""')}"`;
}

function triggerFileDownload(filename, content, mimeType) {
  const blob = new Blob([content], { type: mimeType });
  const url = URL.createObjectURL(blob);
  const link = document.createElement("a");
  link.href = url;
  link.download = filename;
  document.body.append(link);
  link.click();
  link.remove();
  URL.revokeObjectURL(url);
}

function triggerCsvDownload(filename, content) {
  triggerFileDownload(filename, content, "text/csv;charset=utf-8");
}

function sanitizeFilename(value) {
  return value.replace(/[^a-z0-9-_]+/gi, "-").replace(/^-+|-+$/g, "") || "product-order";
}

function downloadSessionAsJson(session) {
  const safeName = sanitizeFilename(session.name || "product-order");
  const json = JSON.stringify(session, null, 2);
  triggerFileDownload(`${safeName}.json`, json, "application/json;charset=utf-8");
}

function isValidImportedSession(candidate) {
  return Boolean(
    candidate
      && typeof candidate === "object"
      && typeof candidate.name === "string"
      && candidate.name.trim()
      && candidate.data
      && typeof candidate.data === "object"
      && Array.isArray(candidate.data.rows),
  );
}

function importSessionObject(session) {
  if (!isValidImportedSession(session)) {
    setFeedback("That JSON file is not a valid saved order.");
    return false;
  }

  const normalizedSession = {
    name: session.name.trim(),
    updatedAt: session.updatedAt || new Date().toISOString(),
    data: {
      purchaseCurrency: session.data.purchaseCurrency || "EUR",
      purchaseDate: session.data.purchaseDate || today,
      customsTotal: session.data.customsTotal || "0",
      shippingTotal: session.data.shippingTotal || "0",
      vatPercent: session.data.vatPercent || "25",
      manualRate: session.data.manualRate || "",
      rows: Array.isArray(session.data.rows) ? session.data.rows : [],
    },
  };

  const sessions = getStoredSessions().filter((item) => item.name !== normalizedSession.name);
  sessions.push(normalizedSession);
  saveStoredSessions(sessions);
  refreshSavedSessions(normalizedSession.name);
  els.sessionName.value = normalizedSession.name;
  applySessionData(normalizedSession.data);

  if (getNumericValue(els.manualRate) > 0) {
    recalculate();
  } else {
    fetchHistoricalRate();
  }

  setFeedback(`Imported order "${normalizedSession.name}" from JSON.`);
  return true;
}

async function handleImportJsonFile(event) {
  const file = event.target.files?.[0];
  if (!file) {
    return;
  }

  try {
    const content = await file.text();
    const parsed = JSON.parse(content);
    importSessionObject(parsed);
  } catch (error) {
    console.error(error);
    setFeedback("Could not import that JSON file.");
  } finally {
    els.importJsonInput.value = "";
  }
}

async function importAllBundledJson() {
  try {
    const manifestResponse = await fetch("./bundled-orders.json");
    if (!manifestResponse.ok) {
      throw new Error(`Manifest lookup failed: ${manifestResponse.status}`);
    }

    const manifest = await manifestResponse.json();
    const files = Array.isArray(manifest?.files) ? manifest.files : [];
    if (!files.length) {
      setFeedback("No bundled JSON files were found to import.");
      return;
    }

    let importedCount = 0;
    for (const file of files) {
      const response = await fetch(`./${encodeURIComponent(file)}`);
      if (!response.ok) {
        continue;
      }

      try {
        const parsed = JSON.parse(await response.text());
        if (importSessionObject(parsed)) {
          importedCount += 1;
        }
      } catch (error) {
        console.error(error);
      }
    }

    setFeedback(
      importedCount > 0
        ? `Imported ${importedCount} bundled JSON order${importedCount === 1 ? "" : "s"}.`
        : "No valid bundled JSON orders could be imported.",
    );
  } catch (error) {
    console.error(error);
    setFeedback("Could not import bundled JSON files.");
  }
}

function getStoredSessions() {
  try {
    const raw = window.localStorage.getItem(STORAGE_KEY);
    if (!raw) {
      return memorySessions;
    }

    const parsed = JSON.parse(raw);
    return Array.isArray(parsed) ? parsed : [];
  } catch (error) {
    console.error(error);
    return memorySessions;
  }
}

function saveStoredSessions(sessions) {
  memorySessions = sessions;
  try {
    window.localStorage.setItem(STORAGE_KEY, JSON.stringify(sessions));
  } catch (error) {
    console.error(error);
    setFeedback("Browser storage is unavailable here, so orders are only kept for this tab.");
  }
}

function refreshSavedSessions(selectedName = "") {
  const sessions = getStoredSessions();
  const previousValue = selectedName || els.savedSessions.value;

  els.savedSessions.innerHTML = "";

  if (!sessions.length) {
    const option = document.createElement("option");
    option.value = "";
    option.textContent = "No saved orders yet";
    els.savedSessions.append(option);
    els.savedSessions.value = "";
    return;
  }

  const placeholder = document.createElement("option");
  placeholder.value = "";
  placeholder.textContent = "Choose a saved order";
  els.savedSessions.append(placeholder);

  sessions
    .sort((a, b) => a.name.localeCompare(b.name))
    .forEach((session) => {
      const option = document.createElement("option");
      option.value = session.name;
      option.textContent = `${session.name} (${session.updatedAt.slice(0, 10)})`;
      els.savedSessions.append(option);
    });

  els.savedSessions.value = sessions.some((session) => session.name === previousValue) ? previousValue : "";
}

function collectSessionData() {
  return {
    purchaseCurrency: els.purchaseCurrency.value,
    purchaseDate: els.purchaseDate.value,
    customsTotal: els.customsTotal.value,
    shippingTotal: els.shippingTotal.value,
    vatPercent: els.vatPercent.value,
    manualRate: els.manualRate.value,
    rows: getRows().map((row) => ({
      name: row.querySelector(".product-name").value.trim(),
      quantity: row.querySelector(".quantity").value,
      subtotal: row.querySelector(".subtotal").value,
      pricingMode: row.querySelector(".pricing-mode").value,
      gainPercent: row.querySelector(".gain-percent").value,
      targetPriceGross: row.querySelector(".target-price-gross").value,
    })),
  };
}

function applySessionData(session) {
  els.purchaseCurrency.value = session.purchaseCurrency || "EUR";
  els.purchaseDate.value = session.purchaseDate || today;
  els.customsTotal.value = session.customsTotal || "0";
  els.shippingTotal.value = session.shippingTotal || "0";
  els.vatPercent.value = session.vatPercent || "25";
  els.manualRate.value = session.manualRate || "";

  els.rows.innerHTML = "";
  if (Array.isArray(session.rows) && session.rows.length) {
    session.rows.forEach((row) => {
      createRow({
        name: row.name || "",
        quantity: Number.parseFloat(row.quantity) || 1,
        subtotal: Number.parseFloat(row.subtotal) || 0,
        pricingMode: row.pricingMode || "margin",
        gainPercent: Number.parseFloat(row.gainPercent) || 0,
        targetPriceGross: Number.parseFloat(row.targetPriceGross) || 0,
      });
    });
  } else {
    createRow();
  }
}

function saveCurrentSession() {
  const name = els.sessionName.value.trim();
  if (!name) {
    setFeedback("Enter an order name before saving.");
    return;
  }

  const sessions = getStoredSessions().filter((session) => session.name !== name);
  const session = {
    name,
    updatedAt: new Date().toISOString(),
    data: collectSessionData(),
  };
  sessions.push(session);

  saveStoredSessions(sessions);
  refreshSavedSessions(name);
  downloadSessionAsJson(session);
  setFeedback(`Saved order "${name}" in this browser and downloaded a JSON backup.`);
}

function loadSelectedSession() {
  const name = els.savedSessions.value;
  if (!name) {
    setFeedback("Choose a saved order to load.");
    return;
  }

  const session = getStoredSessions().find((item) => item.name === name);
  if (!session) {
    refreshSavedSessions();
    setFeedback("That saved order is no longer available.");
    return;
  }

  els.sessionName.value = session.name;
  applySessionData(session.data);

  if (getNumericValue(els.manualRate) > 0) {
    recalculate();
  } else {
    fetchHistoricalRate();
  }

  setFeedback(`Loaded order "${name}".`);
}

function deleteSelectedSession() {
  const name = els.savedSessions.value || els.sessionName.value.trim();
  if (!name) {
    setFeedback("Choose a saved order to delete.");
    return;
  }

  const sessions = getStoredSessions();
  const remaining = sessions.filter((session) => session.name !== name);

  if (remaining.length === sessions.length) {
    setFeedback("That saved order was not found.");
    return;
  }

  saveStoredSessions(remaining);
  refreshSavedSessions();
  if (els.sessionName.value.trim() === name) {
    els.sessionName.value = "";
  }
  setFeedback(`Deleted order "${name}".`);
}

function createRow(values = {}) {
  const fragment = els.rowTemplate.content.cloneNode(true);
  const row = fragment.querySelector(".product-card");
  const nameInput = row.querySelector(".product-name");
  const quantityInput = row.querySelector(".quantity");
  const subtotalInput = row.querySelector(".subtotal");
  const pricingModeInput = row.querySelector(".pricing-mode");
  const gainPercentInput = row.querySelector(".gain-percent");
  const targetPriceGrossInput = row.querySelector(".target-price-gross");
  const currencyLabel = row.querySelector(".purchase-currency-inline");

  nameInput.value = values.name ?? "";
  quantityInput.value = values.quantity ?? 1;
  subtotalInput.value = values.subtotal ?? 0;
  pricingModeInput.value = values.pricingMode ?? "margin";
  gainPercentInput.value = values.gainPercent ?? 30;
  targetPriceGrossInput.value = values.targetPriceGross ?? 0;
  currencyLabel.textContent = els.purchaseCurrency.value;

  function syncPricingModeState() {
    const isMarginMode = pricingModeInput.value === "margin";
    gainPercentInput.disabled = !isMarginMode;
    targetPriceGrossInput.disabled = isMarginMode;
    gainPercentInput.closest(".product-field")?.classList.toggle("is-disabled", !isMarginMode);
    targetPriceGrossInput.closest(".product-field")?.classList.toggle("is-disabled", isMarginMode);
  }

  syncPricingModeState();

  row.querySelector(".remove-row").addEventListener("click", () => {
    row.remove();
    if (!els.rows.children.length) {
      createRow();
    }
    recalculate();
  });

  [nameInput, quantityInput, subtotalInput, pricingModeInput, gainPercentInput, targetPriceGrossInput].forEach((input) => {
    input.addEventListener("input", recalculate);
  });

  pricingModeInput.addEventListener("change", () => {
    syncPricingModeState();
    recalculate();
  });

  els.rows.append(row);
}

function getRows() {
  return [...els.rows.querySelectorAll(".product-card")];
}

function getRowData(row) {
  const quantity = clamp(getNumericValue(row.querySelector(".quantity")), 1, Number.MAX_SAFE_INTEGER);
  const subtotal = Math.max(getNumericValue(row.querySelector(".subtotal")), 0);
  const pricingMode = row.querySelector(".pricing-mode").value === "price" ? "price" : "margin";
  const gainPercent = Math.max(getNumericValue(row.querySelector(".gain-percent")), 0);
  const targetPriceGross = Math.max(getNumericValue(row.querySelector(".target-price-gross")), 0);
  return {
    row,
    name: row.querySelector(".product-name").value.trim(),
    quantity,
    subtotal,
    pricingMode,
    gainPercent,
    targetPriceGross,
  };
}

function exportCurrentOrderToCsv() {
  const rows = getRows().map(getRowData);
  const customsTotal = Math.max(getNumericValue(els.customsTotal), 0);
  const shippingTotal = Math.max(getNumericValue(els.shippingTotal), 0);
  const vat = Math.max(getNumericValue(els.vatPercent) / 100, 0);
  const rate = getEffectiveExchangeRate();

  if (!rate) {
    setFeedback("Add a valid exchange rate before exporting.");
    return;
  }

  const totalSubtotal = rows.reduce((sum, item) => sum + item.subtotal, 0);
  const header = [
    "Product",
    "Quantity",
    `Subtotal ${els.purchaseCurrency.value}`,
    "Unit cost NOK",
    "Shipping share NOK",
    "Customs share NOK",
    "Cost incl MVA NOK",
    "Pricing mode",
    "Target gain %",
    "Target sales price incl MVA NOK",
    "Sales price ex MVA NOK",
    "Sales price incl MVA NOK",
    "Actual company gain NOK",
    "Actual gain %",
    "Max discount before break-even %",
  ];

  const lines = [header.map(escapeCsvValue).join(",")];

  rows.forEach((item) => {
    const allocationRatio = totalSubtotal > 0 ? item.subtotal / totalSubtotal : 0;
    const customsShare = customsTotal * allocationRatio;
    const shippingShare = shippingTotal * allocationRatio;
    const unitCostPurchaseCurrency = item.quantity > 0 ? item.subtotal / item.quantity : 0;
    const unitCustomsNok = item.quantity > 0 ? customsShare / item.quantity : 0;
    const unitShippingPurchaseCurrency = item.quantity > 0 ? shippingShare / item.quantity : 0;
    const unitProductCostNok = unitCostPurchaseCurrency * rate;
    const unitShippingNok = unitShippingPurchaseCurrency * rate;
    const unitCostNok = unitProductCostNok + unitShippingNok + unitCustomsNok;
    const unitCostIncVat = unitProductCostNok * (1 + vat) + unitShippingNok + unitCustomsNok;
    const unitSalesPriceGross = item.pricingMode === "price"
      ? item.targetPriceGross
      : (unitCostNok * (1 + item.gainPercent / 100)) * (1 + vat);
    const unitSalesPriceNet = item.pricingMode === "price"
      ? unitSalesPriceGross / (1 + vat)
      : unitCostNok * (1 + item.gainPercent / 100);
    const unitCompanyGain = unitSalesPriceNet - unitCostNok;
    const actualGainPercent = unitCostNok > 0 ? (unitCompanyGain / unitCostNok) * 100 : 0;
    const breakEvenDiscountNok = Math.max(unitSalesPriceGross - (unitCostNok * (1 + vat)), 0);
    const breakEvenDiscountPercent = unitSalesPriceGross > 0 ? (breakEvenDiscountNok / unitSalesPriceGross) * 100 : 0;

    const line = [
      item.name,
      item.quantity,
      item.subtotal.toFixed(2),
      unitCostNok.toFixed(2),
      (unitShippingPurchaseCurrency * rate).toFixed(2),
      unitCustomsNok.toFixed(2),
      unitCostIncVat.toFixed(2),
      item.pricingMode,
      item.gainPercent.toFixed(1),
      item.targetPriceGross.toFixed(2),
      unitSalesPriceNet.toFixed(2),
      unitSalesPriceGross.toFixed(2),
      unitCompanyGain.toFixed(2),
      actualGainPercent.toFixed(1),
      breakEvenDiscountPercent.toFixed(1),
    ];

    lines.push(line.map(escapeCsvValue).join(","));
  });

  const orderName = els.sessionName.value.trim() || "product-order";
  const safeName = sanitizeFilename(orderName);
  triggerCsvDownload(`${safeName}.csv`, lines.join("\n"));
  setFeedback(`Exported CSV for "${orderName}".`);
}

function getEffectiveExchangeRate() {
  const purchaseCurrency = els.purchaseCurrency.value;
  if (purchaseCurrency === "NOK") {
    return 1;
  }

  const manualRate = getNumericValue(els.manualRate);
  if (manualRate > 0) {
    state.exchangeRateSource = "manual";
    return manualRate;
  }

  if (state.exchangeRate && state.exchangeRate > 0) {
    return state.exchangeRate;
  }

  return null;
}

function updateFxPanel(rate) {
  const purchaseCurrency = els.purchaseCurrency.value;

  if (purchaseCurrency === "NOK") {
    els.fxRate.textContent = "1 NOK";
    els.fxStatus.textContent = "No conversion is needed because the buy and sell currencies are the same.";
    return;
  }

  if (!rate) {
    els.fxRate.textContent = "Missing rate";
    if (state.exchangeRateSource === "file-protocol") {
      els.fxStatus.textContent = "This page is opened directly from your computer, so automatic FX lookup is blocked. Enter a manual FX override or serve the folder from localhost.";
    } else if (state.exchangeRateSource === "missing-date") {
      els.fxStatus.textContent = "Choose a purchase date to fetch the historical exchange rate.";
    } else if (state.exchangeRateSource === "failed") {
      els.fxStatus.textContent = "Automatic lookup failed. Check your internet connection, purchase date, or try a manual FX override.";
    } else {
      els.fxStatus.textContent = "Automatic lookup is not available yet. Enter a manual FX override to continue accurately.";
    }
    return;
  }

  els.fxRate.textContent = `1 ${purchaseCurrency} = ${rate.toFixed(4)} NOK`;
  const sourceLabel = state.exchangeRateSource === "manual" ? "manual override" : "historical market rate";
  els.fxStatus.textContent = `Using ${sourceLabel} for ${els.purchaseDate.value || "the selected purchase date"}.`;
}

function recalculate() {
  [...els.rows.querySelectorAll(".purchase-currency-inline")].forEach((label) => {
    label.textContent = els.purchaseCurrency.value;
  });

  const rows = getRows().map(getRowData);
  const customsTotal = Math.max(getNumericValue(els.customsTotal), 0);
  const shippingTotal = Math.max(getNumericValue(els.shippingTotal), 0);
  const vat = Math.max(getNumericValue(els.vatPercent) / 100, 0);
  const rate = getEffectiveExchangeRate();

  updateFxPanel(rate);

  const totalSubtotal = rows.reduce((sum, item) => sum + item.subtotal, 0);
  let totalConvertedCost = 0;
  let totalCostIncVat = 0;
  let totalSalesNet = 0;
  let totalOutputVat = 0;
  let totalCompanyGain = 0;

  rows.forEach((item) => {
    const allocationRatio = totalSubtotal > 0 ? item.subtotal / totalSubtotal : 0;
    const customsShare = customsTotal * allocationRatio;
    const shippingShare = shippingTotal * allocationRatio;
    const lineCostBeforeVatPurchaseCurrency = item.subtotal + shippingShare;

    const unitCostPurchaseCurrency = item.quantity > 0 ? item.subtotal / item.quantity : 0;
    const unitCustomsNok = item.quantity > 0 ? customsShare / item.quantity : 0;
    const unitShippingPurchaseCurrency = item.quantity > 0 ? shippingShare / item.quantity : 0;
    const unitProductCostNok = rate ? unitCostPurchaseCurrency * rate : 0;
    const unitCostNok = rate ? unitProductCostNok + (unitShippingPurchaseCurrency * rate) + unitCustomsNok : 0;
    const unitShippingNok = rate ? unitShippingPurchaseCurrency * rate : 0;
    const unitCostIncVat = unitProductCostNok * (1 + vat) + unitShippingNok + unitCustomsNok;
    const unitSalesPriceGross = item.pricingMode === "price"
      ? item.targetPriceGross
      : (unitCostNok * (1 + item.gainPercent / 100)) * (1 + vat);
    const unitSalesPriceNet = item.pricingMode === "price"
      ? unitSalesPriceGross / (1 + vat)
      : unitCostNok * (1 + item.gainPercent / 100);
    const unitCompanyGain = unitSalesPriceNet - unitCostNok;
    const actualGainPercent = unitCostNok > 0 ? (unitCompanyGain / unitCostNok) * 100 : 0;
    const breakEvenDiscountNok = Math.max(unitSalesPriceGross - (unitCostNok * (1 + vat)), 0);
    const breakEvenDiscountPercent = unitSalesPriceGross > 0 ? (breakEvenDiscountNok / unitSalesPriceGross) * 100 : 0;

    const convertedLineCost = rate ? (lineCostBeforeVatPurchaseCurrency * rate) + customsShare : 0;
    const convertedLineCostIncVat = rate ? (item.subtotal * rate * (1 + vat)) + (shippingShare * rate) + customsShare : 0;
    const salesLineTotalNet = unitSalesPriceNet * item.quantity;
    const outputVatLineTotal = (unitSalesPriceGross - unitSalesPriceNet) * item.quantity;
    const companyGainLineTotal = unitCompanyGain * item.quantity;

    totalConvertedCost += convertedLineCost;
    totalCostIncVat += convertedLineCostIncVat;
    totalSalesNet += salesLineTotalNet;
    totalOutputVat += outputVatLineTotal;
    totalCompanyGain += companyGainLineTotal;

    item.row.querySelector(".unit-cost").textContent = rate
      ? formatMoney(unitCostNok, "NOK")
      : "Add FX rate";
    item.row.querySelector(".shipping-share").textContent = rate
      ? formatMoney(unitShippingNok, "NOK")
      : "Add FX rate";
    item.row.querySelector(".customs-share").textContent = rate
      ? formatMoney(unitCustomsNok, "NOK")
      : "Add FX rate";
    item.row.querySelector(".cost-inc-vat").textContent = rate
      ? formatMoney(unitCostIncVat, "NOK")
      : "Add FX rate";
    item.row.querySelector(".sales-price-net").textContent = rate
      ? formatMoney(unitSalesPriceNet, "NOK")
      : "Add FX rate";
    item.row.querySelector(".sales-price-gross").textContent = rate
      ? formatMoney(unitSalesPriceGross, "NOK")
      : "Add FX rate";
    item.row.querySelector(".company-gain").textContent = rate
      ? formatMoney(unitCompanyGain, "NOK")
      : "Add FX rate";
    item.row.querySelector(".actual-gain-percent").textContent = rate
      ? formatPercent(actualGainPercent)
      : "Add FX rate";
    item.row.querySelector(".break-even-discount").textContent = rate
      ? formatPercent(breakEvenDiscountPercent)
      : "Add FX rate";
  });

  els.summaryBuySubtotal.textContent = formatMoney(totalSubtotal, els.purchaseCurrency.value);
  els.summaryCustoms.textContent = formatMoney(customsTotal, "NOK");
  els.summaryShipping.textContent = formatMoney(shippingTotal, els.purchaseCurrency.value);
  els.summaryLanded.textContent = rate ? formatMoney(totalConvertedCost, "NOK") : "Add FX rate";
  els.summaryCostIncVat.textContent = rate ? formatMoney(totalCostIncVat, "NOK") : "Add FX rate";
  els.summarySalesTotal.textContent = rate ? formatMoney(totalSalesNet, "NOK") : "Add FX rate";
  els.summaryOutputVat.textContent = rate ? formatMoney(totalOutputVat, "NOK") : "Add FX rate";
  els.summaryCompanyGain.textContent = rate ? formatMoney(totalCompanyGain, "NOK") : "Add FX rate";
  els.summaryNetMargin.textContent = rate && totalSalesNet > 0 ? formatPercent((totalCompanyGain / totalSalesNet) * 100) : "Add FX rate";
}

async function fetchHistoricalRate() {
  const purchaseCurrency = els.purchaseCurrency.value;
  const date = els.purchaseDate.value;
  const manualRate = getNumericValue(els.manualRate);

  if (purchaseCurrency === "NOK") {
    state.exchangeRate = 1;
    state.exchangeRateSource = "same-currency";
    recalculate();
    return;
  }

  if (manualRate > 0) {
    recalculate();
    return;
  }

  if (isFileProtocol()) {
    state.exchangeRate = null;
    state.exchangeRateSource = "file-protocol";
    recalculate();
    return;
  }

  if (!date) {
    state.exchangeRate = null;
    state.exchangeRateSource = "missing-date";
    recalculate();
    return;
  }

  els.fxRate.textContent = "Loading…";
  els.fxStatus.textContent = "Looking up the historical exchange rate for the selected date.";

  try {
    const url = `https://api.frankfurter.dev/v1/${date}?base=${encodeURIComponent(purchaseCurrency)}&symbols=NOK`;
    const response = await fetch(url);
    if (!response.ok) {
      throw new Error(`Rate lookup failed: ${response.status}`);
    }

    const data = await response.json();
    const fetchedRate = data?.rates?.NOK;
    if (!Number.isFinite(fetchedRate)) {
      throw new Error("No rate returned");
    }

    state.exchangeRate = fetchedRate;
    state.exchangeRateSource = "api";
  } catch (error) {
    state.exchangeRate = null;
    state.exchangeRateSource = "failed";
    console.error(error);
  }

  recalculate();
}

function loadSampleData() {
  els.purchaseCurrency.value = "EUR";
  els.purchaseDate.value = today;
  els.customsTotal.value = "1850";
  els.shippingTotal.value = "420";
  els.vatPercent.value = "25";
  els.manualRate.value = "";

  els.rows.innerHTML = "";
  createRow({ name: "Wireless Mouse", quantity: 12, subtotal: 960, pricingMode: "margin", gainPercent: 28, targetPriceGross: 0 });
  createRow({ name: "Mechanical Keyboard", quantity: 8, subtotal: 1280, pricingMode: "price", gainPercent: 35, targetPriceGross: 2499 });
  createRow({ name: "USB-C Dock", quantity: 5, subtotal: 725, pricingMode: "margin", gainPercent: 40, targetPriceGross: 0 });
  fetchHistoricalRate();
}

function resetForm() {
  els.purchaseCurrency.value = "EUR";
  els.purchaseDate.value = today;
  els.customsTotal.value = "0";
  els.shippingTotal.value = "0";
  els.vatPercent.value = "25";
  els.manualRate.value = "";
  els.sessionName.value = "";
  state.exchangeRate = null;
  state.exchangeRateSource = "pending";

  els.rows.innerHTML = "";
  createRow();
  fetchHistoricalRate();
}

function initializeApp() {
  if (!hasRequiredElements()) {
    console.error("Pricing calculator failed to initialize: missing required DOM elements.");
    return;
  }

  els.purchaseDate.value = today;

  els.addRow.addEventListener("click", () => {
    createRow();
    recalculate();
  });

  els.loadSample.addEventListener("click", loadSampleData);
  els.resetForm.addEventListener("click", resetForm);
  els.themeToggle.addEventListener("click", toggleTheme);
  els.saveSession.addEventListener("click", saveCurrentSession);
  els.loadSession.addEventListener("click", loadSelectedSession);
  els.importJson.addEventListener("click", () => els.importJsonInput.click());
  els.importJsonInput.addEventListener("change", handleImportJsonFile);
  els.importAllJson.addEventListener("click", importAllBundledJson);
  els.deleteSession.addEventListener("click", deleteSelectedSession);
  els.exportCsv.addEventListener("click", exportCurrentOrderToCsv);

  [els.purchaseCurrency, els.purchaseDate].forEach((input) => {
    input.addEventListener("change", fetchHistoricalRate);
  });

  [els.customsTotal, els.shippingTotal, els.vatPercent].forEach((input) => {
    input.addEventListener("input", recalculate);
  });

  els.manualRate.addEventListener("input", fetchHistoricalRate);

  applyTheme(loadThemePreference());
  refreshSavedSessions();
  createRow();
  fetchHistoricalRate();
}

initializeApp();
