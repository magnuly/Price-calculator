#!/bin/bash
SCRIPT_DIR="$(cd "$(dirname "$0")" && pwd)"
cd "$SCRIPT_DIR" || exit 1

if command -v python3 >/dev/null 2>&1; then
  python3 "$SCRIPT_DIR/open_calculator.py"
elif command -v python >/dev/null 2>&1; then
  python "$SCRIPT_DIR/open_calculator.py"
else
  echo "Python 3 was not found on this Mac."
  echo "Install Python 3 and run this file again, or run:"
  echo "python3 -m http.server 8000"
  echo "Then open http://localhost:8000/index.html in your browser."
  read -r -p "Press Enter to close..."
fi
