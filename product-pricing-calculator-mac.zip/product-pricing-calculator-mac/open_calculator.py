from __future__ import annotations

import http.server
import os
import socketserver
import threading
import time
import webbrowser
from pathlib import Path


HOST = "127.0.0.1"
ROOT = Path(__file__).resolve().parent


class ReusableTCPServer(socketserver.TCPServer):
    allow_reuse_address = True


def start_server() -> ReusableTCPServer:
    os.chdir(ROOT)
    handler = http.server.SimpleHTTPRequestHandler
    server = ReusableTCPServer((HOST, 0), handler)
    thread = threading.Thread(target=server.serve_forever, daemon=True)
    thread.start()
    return server


def main() -> None:
    server = start_server()
    port = server.server_address[1]
    url = f"http://{HOST}:{port}/index.html"
    print(f"Opening calculator at {url}")
    webbrowser.open(url)

    try:
        while True:
            time.sleep(1)
    except KeyboardInterrupt:
        print("\nStopping local calculator server...")
        server.shutdown()
        server.server_close()


if __name__ == "__main__":
    main()
